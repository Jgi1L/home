Monolog Bridge
==============

Provides integration for Monolog with various Symfony2 components.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Bridge/Monolog/
    $ composer.phar install
    $ phpunit
