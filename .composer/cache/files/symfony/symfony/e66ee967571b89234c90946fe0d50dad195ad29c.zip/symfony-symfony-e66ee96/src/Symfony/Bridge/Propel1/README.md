Propel Bridge
=============

Provides integration for Propel with various Symfony2 components.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Bridge/Propel1/
    $ composer.phar install
    $ phpunit
