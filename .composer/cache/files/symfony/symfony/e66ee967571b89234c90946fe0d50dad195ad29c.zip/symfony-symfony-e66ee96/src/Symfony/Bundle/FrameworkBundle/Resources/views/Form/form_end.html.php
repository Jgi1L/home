<?php if (!isset($render_rest) || $render_rest): ?>
<?php echo $view['form']->rest($form) ?>
<?php endif ?>
</form>
