Container tags
==============

tag1
----

definition_2
~~~~~~~~~~~~

- Class: `Full\Qualified\Class2`
- Scope: `container`
- Public: no
- Synthetic: yes
- File: `/path/to/file`


tag2
----

definition_2
~~~~~~~~~~~~

- Class: `Full\Qualified\Class2`
- Scope: `container`
- Public: no
- Synthetic: yes
- File: `/path/to/file`
