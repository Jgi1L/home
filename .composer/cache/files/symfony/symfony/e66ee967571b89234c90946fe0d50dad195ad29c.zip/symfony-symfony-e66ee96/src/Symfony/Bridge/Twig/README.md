Twig Bridge
===========

Provides integration for [Twig](http://twig.sensiolabs.org/) with various
Symfony2 components.

Resources
---------

If you want to run the unit tests, install dev dependencies before
running PHPUnit:

    $ cd path/to/Symfony/Bridge/Twig/
    $ composer.phar install
    $ phpunit
