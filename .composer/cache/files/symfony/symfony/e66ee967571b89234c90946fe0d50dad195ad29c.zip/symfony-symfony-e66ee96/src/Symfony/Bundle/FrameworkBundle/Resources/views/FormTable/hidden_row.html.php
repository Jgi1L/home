<tr style="display: none">
    <td colspan="2">
        <?php echo $view['form']->widget($form) ?>
    </td>
</tr>
