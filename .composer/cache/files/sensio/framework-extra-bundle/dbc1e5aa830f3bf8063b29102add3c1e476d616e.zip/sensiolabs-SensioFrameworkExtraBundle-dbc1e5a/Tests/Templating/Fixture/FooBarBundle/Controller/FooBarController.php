<?php

namespace Sensio\Bundle\FrameworkExtraBundle\Tests\Templating\Fixture\FooBarBundle\Controller;

class FooBarController
{
}
